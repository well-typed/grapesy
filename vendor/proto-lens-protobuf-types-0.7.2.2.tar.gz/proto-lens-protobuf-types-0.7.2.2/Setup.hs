import Data.ProtoLens.Setup

main = defaultMainGeneratingProtos "proto-src"
